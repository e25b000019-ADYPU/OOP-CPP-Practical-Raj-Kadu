# Step-by-step Mac + VS Code guide

## A. One-time setup
1. Open **Terminal** (Command + Space, type Terminal).
2. Install Apple's command-line compiler tools:
   `xcode-select --install`
3. Follow the installation prompt. Check compiler:
   `clang++ --version`
4. Download and install Visual Studio Code from the official VS Code website.
5. Open VS Code → Extensions → search **C/C++** → install the Microsoft C/C++ extension.

## B. Open the practical folder
1. Unzip the submission package.
2. Open VS Code.
3. Choose **File → Open Folder…**.
4. Select `CPP_12_Practicals_Submission/source_code`.
5. In Explorer, click the required `.cpp` file, for example `01_fundamentals.cpp`.

## C. Compile and run (recommended: VS Code integrated terminal)
1. Choose **Terminal → New Terminal**.
2. Confirm terminal is in the `source_code` folder. If not, use `cd` to navigate there.
3. Compile:
   `clang++ -std=c++17 -Wall -Wextra 01_fundamentals.cpp -o practical01`
4. Run:
   `./practical01`
5. Enter the sample input when prompted and press Return.
6. If compilation reports an error, read the filename and line number, correct the code, save (Command + S), and compile again.

## D. Compile any of the 12 programs
Use the matching pair:
- `01_fundamentals.cpp` → `clang++ -std=c++17 -Wall -Wextra 01_fundamentals.cpp -o practical01`
- `02_bank_account.cpp` → `clang++ -std=c++17 -Wall -Wextra 02_bank_account.cpp -o practical02`
- `03_rule_of_five.cpp` → `clang++ -std=c++17 -Wall -Wextra 03_rule_of_five.cpp -o practical03`
- `04_smart_pointers.cpp` → `clang++ -std=c++17 -Wall -Wextra 04_smart_pointers.cpp -o practical04`
- `05_inheritance.cpp` → `clang++ -std=c++17 -Wall -Wextra 05_inheritance.cpp -o practical05`
- `06_runtime_polymorphism.cpp` → `clang++ -std=c++17 -Wall -Wextra 06_runtime_polymorphism.cpp -o practical06`
- `07_overloading.cpp` → `clang++ -std=c++17 -Wall -Wextra 07_overloading.cpp -o practical07`
- `08_factory_pattern.cpp` → `clang++ -std=c++17 -Wall -Wextra 08_factory_pattern.cpp -o practical08`
- `09_template_stack.cpp` → `clang++ -std=c++17 -Wall -Wextra 09_template_stack.cpp -o practical09`
- `10_custom_exceptions.cpp` → `clang++ -std=c++17 -Wall -Wextra 10_custom_exceptions.cpp -o practical10`
- `11_csv_file_io.cpp` → `clang++ -std=c++17 -Wall -Wextra 11_csv_file_io.cpp -o practical11`
- `12_student_portal.cpp` → `clang++ -std=c++17 -Wall -Wextra 12_student_portal.cpp -o student_portal`

Then run the executable using `./practicalNN` or `./student_portal`.

## E. Practical 12 sample test
Run `./student_portal` and enter:
```
1
101
Aarav Sharma
BTech CSE
87.5
1
102
Mira Patel
BTech CSE
92
2
3
101
4
```
Expected behaviour: two students are added, the list displays both records and grades, searching ID 101 displays Aarav Sharma, and exit saves `students_portal.csv`.
Run it again and choose option 2 to verify that records reload from the CSV file.

## F. Screenshots for the soft-copy manual
Capture genuine screenshots after running the programs:
1. In VS Code, show the `.cpp` source file and terminal command/output.
2. For Practical 1–10, capture one successful run each (combine multiple output sections only if readable).
3. For Practical 11, capture terminal output and the generated `students.csv` file.
4. For Practical 12, capture Add, List, Search, invalid input (for example marks 120), and reload after restarting the program.
5. macOS screenshot shortcuts: `Command + Shift + 4` for selected area; `Command + Shift + 5` for screenshot controls.
6. Save images in a folder named `screenshots`, using names such as `P01_output.png` … `P12_student_portal.png`.
7. Insert them into the matching practical section in Word using **Insert → Pictures → Picture from File**.
8. Screenshots must show your own execution; do not use sample-output text as a substitute for execution evidence.

## G. Fill and export the manual
1. Open `filled_practical_manual.docx` in Microsoft Word or Pages.
2. Fill your name, roll number, class/division and academic year on the cover page.
3. Review each practical's aim, code, sample output, result and explanation.
4. Add your actual screenshots and GitHub repository URL where requested.
5. Save the Word document.
6. Export a PDF: Word → File → Save As / Export → PDF (or Pages → File → Export To → PDF).
7. Submit both the completed DOCX and PDF if your instructor requests both.

## H. GitHub evidence (Practical 1 and 12)
1. Create a GitHub account if needed.
2. On GitHub, click **New repository**, name it `cpp-practicals`, choose Public/Private as instructed, and create it.
3. In Terminal, from the folder containing the project:
   `git init`
   `git add .`
   `git commit -m "Add C++ practical programs and Student Portal"`
4. Add the repository remote copied from GitHub:
   `git remote add origin YOUR_REPOSITORY_URL`
5. Push:
   `git branch -M main`
   `git push -u origin main`
6. Replace `YOUR_REPOSITORY_URL` with your actual repository URL; never submit a placeholder URL.
