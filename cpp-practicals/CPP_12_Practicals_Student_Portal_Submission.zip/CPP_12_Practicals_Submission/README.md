# C++ Programming – 12 Practical Submission Package

## Contents
- `source_code/01_fundamentals.cpp` through `12_student_portal.cpp`
- `diagrams/student_portal_architecture.png`
- `diagrams/student_portal_flowchart.png`
- `filled_practical_manual.docx` (completed practical write-up and solution supplement)
- `RUN_GUIDE_MAC.md`

## Requirements
- macOS with Xcode Command Line Tools (`clang++`)
- Visual Studio Code
- C++17 compiler

## Compile and run one practical
Open Terminal in the `source_code` folder:
```bash
clang++ -std=c++17 -Wall -Wextra 01_fundamentals.cpp -o practical01
./practical01
```
Replace the filename and executable name for the practical you want to run.
For Practical 11 and 12, run from a writable folder because CSV files are created in the current working directory.

## Practical 12 – Student Portal
```bash
cd source_code
clang++ -std=c++17 -Wall -Wextra 12_student_portal.cpp -o student_portal
./student_portal
```
Menu options: Add, List, Search, Save and Exit. Data is saved in `students_portal.csv` in the current working directory.

## Important
The sample outputs in the manual are expected outputs for the sample data shown. Run each program on your Mac and replace/add screenshots of your own successful execution before submission. Do not claim a GitHub push or memory-check run unless you actually performed it.
