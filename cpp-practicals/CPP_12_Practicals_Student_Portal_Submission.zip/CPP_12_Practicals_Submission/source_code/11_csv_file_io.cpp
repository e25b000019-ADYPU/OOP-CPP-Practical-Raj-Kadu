#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

struct Student { int id; string name; double marks; };

int main() {
    const string filename = "students.csv";
    Student data[] = {{101,"Aarav",87.5},{102,"Mira",91.0},{103,"Kabir",78.5}};
    {
        ofstream out(filename);
        if (!out) { cerr << "Cannot open file for writing.\n"; return 1; }
        out << "ID,Name,Marks\n";
        for (const auto& s : data) out << s.id << ',' << s.name << ',' << s.marks << '\n';
    }

    ifstream in(filename);
    if (!in) { cerr << "Cannot open file for reading.\n"; return 1; }
    string line;
    getline(in,line); // skip header
    cout << "Records read from " << filename << ":\n";
    while (getline(in,line)) {
        stringstream ss(line); string id,name,marks;
        getline(ss,id,','); getline(ss,name,','); getline(ss,marks,',');
        cout << id << " | " << name << " | " << marks << '\n';
    }
    in.close();

    fstream file(filename, ios::in | ios::out);
    if (!file) { cerr << "Cannot open file for positioning demo.\n"; return 1; }
    cout << "Initial get position (tellg): " << file.tellg() << '\n';
    file.seekg(0,ios::beg);
    cout << "After seekg to beginning, first char: " << char(file.peek()) << '\n';
    file.seekp(0,ios::end);
    cout << "Write position at end (tellp): " << file.tellp() << '\n';
    file.close();
    return 0;
}