#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountNumber; // private: protected from direct external modification
    double balance;

public:
    BankAccount(string number, double openingBalance)
        : accountNumber(number), balance(openingBalance < 0 ? 0 : openingBalance) {}

    void deposit(double amount) {
        if (amount > 0) balance += amount;
        else cout << "Deposit must be positive.\n";
    }

    void withdraw(double amount) {
        if (amount <= 0) cout << "Withdrawal must be positive.\n";
        else if (amount > balance) cout << "Insufficient balance.\n";
        else balance -= amount;
    }

    void display() const {
        cout << "Account: " << accountNumber << " | Balance: " << balance << '\n';
    }
};

int main() {
    BankAccount a1("AC101", 5000), a2("AC102", 2500);
    a1.deposit(1000);
    a2.withdraw(500);
    a1.display();
    a2.display();
    return 0;
}