#include <iostream>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string n, int a) : name(n), age(a) {}
    void displayPerson() const { cout << "Name: " << name << "\nAge: " << age << '\n'; }
};

class Student : public Person {
protected:
    string studentId, course;
public:
    Student(string n, int a, string id, string c)
        : Person(n,a), studentId(id), course(c) {}
    void displayStudent() const {
        displayPerson();
        cout << "Student ID: " << studentId << "\nCourse: " << course << '\n';
    }
};

class GraduateStudent : public Student {
    string researchTopic;
public:
    GraduateStudent(string n,int a,string id,string c,string topic)
        : Student(n,a,id,c), researchTopic(topic) {}
    void displayGraduate() const {
        displayStudent();
        cout << "Research topic: " << researchTopic << '\n';
    }
};

int main() {
    Student s("Aarav",19,"S101","B.Tech CSE");
    GraduateStudent g("Mira",22,"G201","M.Tech CSE","Machine Learning");
    cout << "--- Student ---\n"; s.displayStudent();
    cout << "\n--- Graduate Student ---\n"; g.displayGraduate();
    return 0;
}