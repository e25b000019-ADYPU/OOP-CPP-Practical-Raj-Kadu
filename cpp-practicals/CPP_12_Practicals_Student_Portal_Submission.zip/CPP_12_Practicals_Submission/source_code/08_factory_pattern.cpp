#include <iostream>
#include <memory>
#include <string>
using namespace std;

class Notification {
public:
    virtual void send(const string& message) const = 0;
    virtual ~Notification() = default;
};
class EmailNotification : public Notification {
public:
    void send(const string& message) const override { cout << "Email notification: " << message << '\n'; }
};
class SMSNotification : public Notification {
public:
    void send(const string& message) const override { cout << "SMS notification: " << message << '\n'; }
};

class NotificationFactory {
public:
    static unique_ptr<Notification> create(const string& type) {
        if (type == "email") return make_unique<EmailNotification>();
        if (type == "sms") return make_unique<SMSNotification>();
        throw invalid_argument("Unknown notification type");
    }
};

int main() {
    try {
        auto email = NotificationFactory::create("email");
        auto sms = NotificationFactory::create("sms");
        email->send("Welcome to the student portal.");
        sms->send("Your registration is confirmed.");
    } catch (const exception& e) {
        cout << "Error: " << e.what() << '\n';
    }
    return 0;
}