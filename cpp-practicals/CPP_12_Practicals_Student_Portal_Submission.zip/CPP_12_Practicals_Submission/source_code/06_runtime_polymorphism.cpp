#include <iostream>
#include <memory>
#include <vector>
using namespace std;

class Shape {
public:
    virtual double area() const = 0; // pure virtual function makes Shape abstract
    virtual ~Shape() = default;
};

class Circle : public Shape {
    double radius;
public:
    explicit Circle(double r) : radius(r) {}
    double area() const override { return 3.141592653589793 * radius * radius; }
};
class Rectangle : public Shape {
    double length, width;
public:
    Rectangle(double l,double w) : length(l),width(w) {}
    double area() const override { return length * width; }
};
class Triangle : public Shape {
    double base,height;
public:
    Triangle(double b,double h) : base(b),height(h) {}
    double area() const override { return 0.5 * base * height; }
};

int main() {
    vector<unique_ptr<Shape>> shapes;
    shapes.push_back(make_unique<Circle>(2));
    shapes.push_back(make_unique<Rectangle>(4,5));
    shapes.push_back(make_unique<Triangle>(6,3));
    cout.setf(ios::fixed); cout.precision(2);
    for (size_t i=0;i<shapes.size();++i)
        cout << "Shape " << i+1 << " area = " << shapes[i]->area() << '\n';
    return 0;
}