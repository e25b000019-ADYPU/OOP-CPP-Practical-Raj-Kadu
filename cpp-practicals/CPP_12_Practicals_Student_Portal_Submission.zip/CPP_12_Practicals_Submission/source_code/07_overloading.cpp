#include <iostream>
using namespace std;

int add(int a,int b) { return a+b; }
double add(double a,double b) { return a+b; }

class ComplexNumber {
    double real, imag;
public:
    ComplexNumber(double r=0,double i=0) : real(r),imag(i) {}
    ComplexNumber operator+(const ComplexNumber& other) const {
        return ComplexNumber(real+other.real, imag+other.imag);
    }
    void display() const { cout << real << (imag>=0 ? " + " : " - ") << (imag>=0 ? imag : -imag) << "i\n"; }
};

int main() {
    cout << "Integer addition: " << add(4,5) << '\n';
    cout << "Decimal addition: " << add(2.5,3.2) << '\n';
    ComplexNumber c1(3,2), c2(1,4);
    ComplexNumber sum = c1 + c2;
    cout << "Complex sum: "; sum.display();
    return 0;
}