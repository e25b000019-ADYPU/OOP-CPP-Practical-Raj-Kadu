#include <iostream>
#include <algorithm>
#include <utility>
using namespace std;

class IntArray {
    int* data;
    size_t size;
public:
    IntArray() : data(nullptr), size(0) { cout << "Default constructor\n"; }
    explicit IntArray(size_t n) : data(n ? new int[n]() : nullptr), size(n) {
        cout << "Parameterized constructor\n";
    }
    IntArray(const IntArray& other) : data(other.size ? new int[other.size] : nullptr), size(other.size) {
        copy(other.data, other.data + size, data);
        cout << "Copy constructor (deep copy)\n";
    }
    IntArray& operator=(const IntArray& other) {
        if (this != &other) {
            int* fresh = other.size ? new int[other.size] : nullptr;
            copy(other.data, other.data + other.size, fresh);
            delete[] data; data = fresh; size = other.size;
        }
        cout << "Copy assignment\n";
        return *this;
    }
    IntArray(IntArray&& other) noexcept : data(other.data), size(other.size) {
        other.data = nullptr; other.size = 0;
        cout << "Move constructor\n";
    }
    IntArray& operator=(IntArray&& other) noexcept {
        if (this != &other) {
            delete[] data; data = other.data; size = other.size;
            other.data = nullptr; other.size = 0;
        }
        cout << "Move assignment\n";
        return *this;
    }
    ~IntArray() { delete[] data; cout << "Destructor\n"; }
    void set(size_t i, int value) { if (i < size) data[i] = value; }
    void display() const { for (size_t i=0;i<size;++i) cout << data[i] << ' '; cout << '\n'; }
};

int main() {
    IntArray a(3); a.set(0,10); a.set(1,20); a.set(2,30);
    IntArray b(a); b.display();
    IntArray c; c = a;
    IntArray d(std::move(a));
    IntArray e; e = std::move(d);
    e.display();
    return 0;
}