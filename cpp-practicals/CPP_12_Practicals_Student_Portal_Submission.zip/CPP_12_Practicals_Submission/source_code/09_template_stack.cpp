#include <iostream>
#include <stack>
#include <string>
#include <stdexcept>
using namespace std;

template <typename T>
class GenericStack {
    stack<T> items;
public:
    void push(const T& value) { items.push(value); }
    void pop() {
        if (items.empty()) throw underflow_error("Cannot pop: stack is empty");
        items.pop();
    }
    const T& top() const {
        if (items.empty()) throw underflow_error("Cannot read top: stack is empty");
        return items.top();
    }
    bool empty() const { return items.empty(); }
};

int main() {
    GenericStack<int> integers; integers.push(10); integers.push(20);
    cout << "Integer stack top: " << integers.top() << '\n'; integers.pop();
    GenericStack<double> decimals; decimals.push(3.14);
    cout << "Float stack top: " << decimals.top() << '\n';
    GenericStack<string> words; words.push("C++"); words.push("Templates");
    cout << "String stack top: " << words.top() << '\n';
    try { integers.pop(); integers.pop(); } // second pop on empty stack
    catch (const exception& e) { cout << "Handled error: " << e.what() << '\n'; }
    return 0;
}