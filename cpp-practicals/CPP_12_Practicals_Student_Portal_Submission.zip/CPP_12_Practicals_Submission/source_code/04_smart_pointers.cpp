#include <iostream>
#include <memory>
using namespace std;

struct Record {
    int id;
    explicit Record(int value) : id(value) { cout << "Record " << id << " created\n"; }
    ~Record() { cout << "Record " << id << " destroyed\n"; }
};

int main() {
    unique_ptr<Record> uniqueRecord = make_unique<Record>(101);
    cout << "unique_ptr owns record ID: " << uniqueRecord->id << '\n';

    shared_ptr<Record> owner1 = make_shared<Record>(202);
    {
        shared_ptr<Record> owner2 = owner1;
        cout << "shared_ptr reference count inside scope: " << owner1.use_count() << '\n';
    }
    cout << "shared_ptr reference count after scope: " << owner1.use_count() << '\n';
    return 0;
}