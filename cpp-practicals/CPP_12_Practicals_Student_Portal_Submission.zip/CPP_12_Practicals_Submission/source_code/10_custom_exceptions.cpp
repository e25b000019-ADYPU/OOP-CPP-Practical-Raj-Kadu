#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

class InvalidAmount : public runtime_error {
public: InvalidAmount() : runtime_error("Amount must be greater than zero.") {}
};
class InsufficientFunds : public runtime_error {
public: InsufficientFunds() : runtime_error("Insufficient funds for withdrawal.") {}
};

class BankAccount {
    double balance;
public:
    explicit BankAccount(double opening) : balance(opening) {}
    void withdraw(double amount) {
        if (amount <= 0) throw InvalidAmount();
        if (amount > balance) throw InsufficientFunds();
        balance -= amount;
        cout << "Withdrawal successful: " << amount << '\n';
    }
    double getBalance() const { return balance; }
};

int main() {
    BankAccount account(5000);
    try { account.withdraw(1200); }
    catch (const InvalidAmount& e) { cout << e.what() << '\n'; }
    catch (const InsufficientFunds& e) { cout << e.what() << '\n'; }
    try { account.withdraw(6000); }
    catch (const InvalidAmount& e) { cout << e.what() << '\n'; }
    catch (const InsufficientFunds& e) { cout << e.what() << '\n'; }
    try { account.withdraw(-50); }
    catch (const InvalidAmount& e) { cout << e.what() << '\n'; }
    catch (const InsufficientFunds& e) { cout << e.what() << '\n'; }
    cout << "Final balance: " << account.getBalance() << '\n';
    return 0;
}