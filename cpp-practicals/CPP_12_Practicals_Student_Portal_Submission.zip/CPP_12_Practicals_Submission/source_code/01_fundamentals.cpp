#include <iostream>
#include <string>
using namespace std;

int main() {
    const double GST_RATE = 0.18;
    string studentName;
    int quantity;
    double price;

    cout << "Enter student name: ";
    getline(cin, studentName);
    cout << "Enter quantity: ";
    cin >> quantity;
    cout << "Enter price per item: ";
    cin >> price;

    double subtotal = quantity * price;
    double total = subtotal + subtotal * GST_RATE;

    cout << "\nStudent: " << studentName << '\n';
    cout << "Subtotal: " << subtotal << '\n';
    cout << "Total including 18% tax: " << total << '\n';
    cout << "Quantity positive? " << (quantity > 0) << '\n';
    cout << "Valid order? " << (quantity > 0 && price >= 0) << '\n';
    return 0;
}