#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <string>
#include <iomanip>
#include <stdexcept>
#include <limits>
using namespace std;

class Person {
protected:
    string name;
public:
    explicit Person(string n) : name(std::move(n)) {}
    virtual void display() const = 0;
    virtual ~Person() = default;
};

class Student : public Person {
    int id;
    string course;
    double marks;
public:
    Student(int i,string n,string c,double m) : Person(std::move(n)),id(i),course(std::move(c)),marks(m) {
        if (id <= 0) throw invalid_argument("Student ID must be positive.");
        if (marks < 0 || marks > 100) throw invalid_argument("Marks must be between 0 and 100.");
    }
    int getId() const { return id; }
    double getMarks() const { return marks; }
    string getCourse() const { return course; }
    string getName() const { return name; }
    string grade() const {
        if (marks >= 90) return "A+";
        if (marks >= 80) return "A";
        if (marks >= 70) return "B";
        if (marks >= 60) return "C";
        if (marks >= 40) return "D";
        return "F";
    }
    void display() const override {
        cout << left << setw(8) << id << setw(20) << name << setw(16)
             << course << setw(8) << marks << grade() << '\n';
    }
};

class StudentPortal {
    map<int,Student> students;
    const string filename = "students_portal.csv";
public:
    void addStudent(const Student& s) {
        if (students.count(s.getId())) throw runtime_error("Student ID already exists.");
        students.emplace(s.getId(),s);
        save();
        cout << "Student added successfully.\n";
    }
    void listStudents() const {
        if (students.empty()) { cout << "No student records found.\n"; return; }
        cout << left << setw(8) << "ID" << setw(20) << "Name" << setw(16)
             << "Course" << setw(8) << "Marks" << "Grade\n";
        cout << string(60,'-') << '\n';
        for (const auto& entry : students) entry.second.display();
    }
    void searchStudent(int id) const {
        auto it = students.find(id);
        if (it == students.end()) throw runtime_error("Student ID not found.");
        cout << "Student found:\n"; it->second.display();
    }
    void save() const {
        ofstream out(filename);
        if (!out) throw runtime_error("Unable to open data file for writing.");
        out << "id,name,course,marks\n";
        for (const auto& p : students) {
            const Student& s=p.second;
            out << s.getId() << ',' << s.getName() << ',' << s.getCourse() << ',' << s.getMarks() << '\n';
        }
    }
    void load() {
        ifstream in(filename);
        if (!in) return; // first run: file will be created after first add
        string line; getline(in,line); // header
        while (getline(in,line)) {
            stringstream ss(line); string id,name,course,marks;
            getline(ss,id,','); getline(ss,name,','); getline(ss,course,','); getline(ss,marks,',');
            try {
                Student s(stoi(id),name,course,stod(marks));
                students.emplace(s.getId(),s);
            } catch (const exception&) {
                cerr << "Skipping invalid record: " << line << '\n';
            }
        }
    }
};

int main() {
    StudentPortal portal;
    portal.load();
    while (true) {
        cout << "\n===== STUDENT PORTAL =====\n"
             << "1. Add student\n2. List students\n3. Search by ID\n4. Save and exit\n"
             << "Choose option: ";
        int choice;
        if (!(cin >> choice)) { cout << "Invalid input. Exiting safely.\n"; break; }
        try {
            if (choice == 1) {
                int id; string name,course; double marks;
                cout << "Enter student ID: "; cin >> id;
                cin.ignore(numeric_limits<streamsize>::max(),'\n');
                cout << "Enter name: "; getline(cin,name);
                cout << "Enter course: "; getline(cin,course);
                cout << "Enter marks (0-100): "; cin >> marks;
                portal.addStudent(Student(id,name,course,marks));
            } else if (choice == 2) {
                portal.listStudents();
            } else if (choice == 3) {
                int id; cout << "Enter student ID to search: "; cin >> id;
                portal.searchStudent(id);
            } else if (choice == 4) {
                cout << "Data saved. Goodbye!\n"; break;
            } else {
                cout << "Please choose 1, 2, 3 or 4.\n";
            }
        } catch (const exception& e) {
            cout << "Error: " << e.what() << '\n';
        }
    }
    return 0;
}